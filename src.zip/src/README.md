css,fonts,images是模板本身的
img ,script，style是定制的。
