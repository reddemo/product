//表单模块
var editableTable=new EditableTable($('#editable-sample'));
editableTable.init();