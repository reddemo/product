/**
 * @function main
 * @requires jquery,bootsrap,xiding,add;
 */



//吸顶
new Xiding('.bang-nav');
console.log(brandHTML)
//添加
new Add({'.bang-js-html1':'<div class="bang-next">' +
            '附件 : ' +
            '<input type="text"> ' +
            '<input type="button" value="选择附件">' +
            '</div>',
          '.bang-js-html4':'<div class="bang-next bang-js-next">'+
                                '附件 : '+
                                '<input type="text">'+
                                ' <input type="button" value="选择附件"> 链接 :'+
                                ' <input type="text">'+
                            '</div>'});