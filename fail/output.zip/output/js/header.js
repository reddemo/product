$('.left_menu').height($(document).height()-100);
$('#openClose').height($(document).height()-100);
$('#openClose').on('click',function(){
	$('#leftMain').toggle();
});