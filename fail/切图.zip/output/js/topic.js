/**
 * @function main
 * @requires jquery,bootsrap,xiding,add;
 */



//吸顶
new Xiding('.bang-nav');

//添加
new Add({'.bang-js-html1':'<div class="bang-next">' +
            '附件 : ' +
            '<input type="text"> ' +
            '<input type="button" value="选择附件">' +
            '</div>',
         '.bang-js-html2:tbody':'<tr class="bang-table-body bang-table-body2"><td class="bang-showid">ID</td>'+
                            '<td class="bang-showsort">排序</td>'+
                            '<td class="bang-showpinpai">品牌</td>'+
                            '<td class="bang-showchexi">车系</td></tr>',
     	 '.bang-js-html3:tbody':'<tr class="bang-table-body bang-table-body2"><td class="bang-showid">ID</td>'+
                            '<td class="bang-showsort">排序</td>'+
                            '<td class="bang-showpinpai">品牌</td>'+
                            '<td class="bang-showchexi">车系</td>'+
                            '<td class="bang-showjiage">价格</td>'+
                            '<td class="bang-showactions">操作</td></tr>',
          '.bang-js-html4':'<div class="bang-next bang-js-next">'+
                                '附件 : '+
                                '<input type="text">'+
                                ' <input type="button" value="选择附件"> 链接 :'+
                                ' <input type="text">'+
                            '</div>'});