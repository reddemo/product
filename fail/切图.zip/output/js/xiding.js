/*!
 * [Xiding description]
 * @Author   wanghongxin492@emao.com
 * @DateTime 2016-03-29T16:54:43+0800
 * @param    {String}                 selector [description]
 */
function Xiding(selector){
	var target=$(selector);
	var html=$(target.prop('outerHTML')).addClass('js-xxx');
	var targetY=target.offset().top;
	var $window=$(window);
	$window.on('scroll',function(){
		if($window.scrollTop()>=targetY){
			target.css({'position':'fixed',
						'top':'0',
						'left':'200px'});
			target.after(html);
		}else{
			target.css({'position':'relative',
						'left':'0'});
			html.remove();
		}
	});	
}