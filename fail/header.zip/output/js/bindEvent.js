var brandHTML = '';
var seriesHTML = {};
//获取品牌数据
getBrands.
then(function(brand) {
    if (brand.code == 0) {
        brandHTML = render(_.chain(brand.data.list).unshift({
            id: 'please',
            brandName: '请选择品牌'
        }).value());
        Add({

            '.bang-js-html3:tbody': '<tr class="bang-table-body bang-table-body2"><td class="bang-showid">ID</td>' +
                '<td class="bang-showsort"><input type="text" class="bang-sort-text"></td>' +
                '<td class="bang-showpinpai"><select class="js-bang-brand">' + brandHTML + '</select></td>' +
                '<td class="bang-showchexi"><select class="js-bang-serie"><option value="please">请选择车系</select></td>' +
                '<td class="bang-showjiage"><input type="text" class="bang-sort-text"></td>' +
                '<td class="bang-actions"><a href="javascript:void 0;" class="bang-submit">提交</a><a href="javascript:void 0;" class="bang-cancel">删除</a></td></tr>',

            '.bang-js-html2:tbody': '<tr class="bang-table-body bang-table-body2"><td class="bang-showid">ID</td>' +
                '<td><input type="text" class="bang-sort-text"></td>' +
                '<td><select class="">' + brandHTML + '</select></td>' +
                '<td class="bang-actions"><a href="javascript:void 0;" class="bang-submit">提交</a><a href="javascript:void 0;" class="bang-cancel">删除</a></td></tr>'
        })
    } else {
        alert(brand.msg);
    }
})['catch'](function() {
    console.log(arguments);
});

//代理页面所有的.js-bang-brand，联动.js-bang-serie
$(document).on('change', '.js-bang-brand', function() {
    var serie = $(this).val();
    var nextSelect = $(this).closest('td').next('td').find('.js-bang-serie');
    if (serie == 'please') {
        alert('请选择品牌');
        return;
    }
    if (!seriesHTML[serie]) {
        getSeriesById(serie).then(function(series) {
            nextSelect.html(seriesHTML[serie] = catSeriesHTML(series.data.list));
        });
    }
});
