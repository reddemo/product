 /*!
  *@requires jquery,bootstrap,add;
  *@function index's main
  */
new Add({'.js-bang-add:.js-bang-table-add-wapper':'<tr class="bang-table-body"><td>1</td>'+
                		"<td>湖北宜昌</td>"+
                		"<td>万达广场</td>"+
                		'<td>2016年03月22日</td>'+
                		'<td>liulu236@emao.com</td>'+
                		'<td>2016年03月22日</td>'+
                		'<td>正常</td>'+
                		'<td>神马</td>'+
                		'<td>西苳</td>'+
                		'<td class="bang-actions">'+
                			'<a href="javascript:void 0;">设置抽奖</a>'+
                			'<a href="javascript:void 0;">设置摇一摇</a>'+
                			'<a href="javascript:void 0;" class="bang-topic">设置专题</a>'+
                			'<a href="javascript:void 0;">录入下订数据</a>'+
                			'<a href="javascript:void 0;">数据</a>'+
                			'<a href="javascript:void 0;" class="bang-cancel">删除</a>'+
                		'</td></tr>'});
