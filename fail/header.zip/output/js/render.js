/**
 * [render description]
 * @Author   wanghongxin492@emao.com
 * @DateTime 2016-03-31T17:30:45+0800
 * @param    {[type]}                 list [description]
 * @return   {[type]}                      [description]
 */
function render(list) {
    return _.reduce(list, function(state, item, index, list) {
        return state + '<option value="' + item.id + '">' + (item.brandName || item.serieName) + '</option>'
    }, '');
}

function catSeriesHTML(list) {
    return render(_.chain(list).unshift({
        'id': 'please',
        'serieName': '请选择车系'

    }).value());
}
