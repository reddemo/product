/**
 * [点击添加按钮，动态插入元素]
 * @Author wanghongxin492@emao.com
 * @DateTime  2016-03-29T15:02:57+0800
 * @param     {[object]}                 opts {:name selector :value htmlString}
 * @example 
 *         点击one selector时，为another selector插入数据
 *         Add({
 *             '.one selecotr:another selector':'<div>'
 *         });
 */
function Add(opts) {
    for (var i in opts) {
        if (opts.hasOwnProperty(i)) {
            !function(i) {
            	var j=i.split(':');
                $(j[0]).on('click', function() {
                    $(opts[i]).appendTo(j[1]?$(this).next().find(j[1]):$(this).parent());
                });
            }(i);
        }
    }
}
