// var bandUrl='http://auto.emao.com/api/getAllBrands';
// var seriesUrl='http://auto.emao.com/api/getSerieByBrand/8/';


    var brandUrl = '../test/brand.json';
    var seriesUrl = '../test/series.json';

    var getBrands = getUrl(brandUrl);

    function getSeriesById(id) {
        return getUrl(seriesUrl);
        return getUrl(seriesUrl + '/' + id);
    }

    

